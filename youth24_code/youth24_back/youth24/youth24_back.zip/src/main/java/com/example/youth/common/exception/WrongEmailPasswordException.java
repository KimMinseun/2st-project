package com.example.youth.common.exception;

public class WrongEmailPasswordException extends RuntimeException{
	
	public WrongEmailPasswordException() {
		// TODO Auto-generated constructor stub
	}
	
}//end class

