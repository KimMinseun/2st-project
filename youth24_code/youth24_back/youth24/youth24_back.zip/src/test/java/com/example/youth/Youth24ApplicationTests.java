package com.example.youth;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class Youth24ApplicationTests {

	@Test
	void contextLoads() {
	}

}
